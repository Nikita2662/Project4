#include "router.h"
#include "HashMap.h"
#include "router.h"

Router::Router(const GeoDatabaseBase& geo_db)
{

}
Router::~Router()
{

}

std::vector<GeoPoint> Router::route(const GeoPoint& pt1, const GeoPoint& pt2) const
{
	return vector<GeoPoint>();
}